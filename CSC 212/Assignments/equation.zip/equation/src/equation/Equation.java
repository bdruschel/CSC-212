package equation;

import java.util.Scanner;
import java.io.*;
/**
 *
 * @author Brandon Druschel
 * course CSC 212 Section 81F
 * date 8-27-15
 * description:
 * Write a Java program that computes Y and Y'. 
 * The equations that determine their values are 
 *      Y = aX^2 + bX + c
 *      Y' = 2aX + b 
 * Input:
 *      The values for X, a, b, and c are provided interactively. 
 *      X is a double and a,b, and c are int variables.  The constraint a not 
 *      being zero must be applied.
 * Output:
 *     Y and Y' 
 */

public class Equation {
    
    public static void main(String[] args) {
        
        //declaration of the variable xy and y' variables. 
        double x;
        double y;
        double y_prime;
        
       /* declare the three int constant holding variables: a, b, and c */
       int a;
       int b;
       int c;
       
         /* abort if a is zero. Note this causes complier error 
          * as a is not yet declared         
          */
         /* needed to receive input values for int and double variables */
        Scanner sc = new Scanner(System.in);
        
        /*input x, a, b, and c. input for x is shown, need input of a,b, and c */
        System.out.print("Please enter the value for X ");
        x= sc.nextDouble();
        
        System.out.print("Please enter the value for a ");
        a= sc.nextInt();
        
         if (a == 0) 
         {
            System.out.println ("Program is aborted; " + ""
                    + "a set at zero makes the function linear");
            System.exit(-1);
         }
         
        System.out.print("Please enter the value for b ");
        b= sc.nextInt();
        
        System.out.print("Please enter the value for c ");
        c= sc.nextInt();
        
       
              
        /*Write the code for calculating y and y' and storing results in 
         * their respective variables */
          y = (a*(x*x)) + (b*x) + c;
          y_prime = 2 * (a*x) + b;
          
        /* Write the code to output y and y' using the format expected
         * in the assignment */
       System.out.println("For X, a, b, and c values: " + x + ", " + a + ", "
               + "" + b + ", and " + c + " respectively, the Y value is " + y);
       System.out.println("For X, a, and b value: " + x + ", " + a + ", and "
               + b + " respectively, the Y' value is " + y_prime);

       /*Programming Challenge
        *Continue to ask for input for the variable a until a value that is not equal to zero is entered for it.
        *Hint: Learn about do/while loops. */
       
       while(a != 0)
       {
        System.out.print("Please enter a new value for a ");
        a= sc.nextInt();
        
        y = (a*(x*x)) + (b*x) + c;
        y_prime = 2 * (a*x) + b;
        
       System.out.println("For X, a, b, and c values: " + x + ", " + a + ", "
               + b + ", and " + c + " respectively, the Y value is " + y);
       System.out.println("For X, a, and b value: " + x + ", " + a + ", and "
               + b + " respectively, the Y' value is " + y_prime);
        
        if (a == 0) {
            System.out.println ("Program is aborted; " + ""
                    + "a set at zero makes the function linear");
            System.exit(-1);
        }
       }
    }
}

