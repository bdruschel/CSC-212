package csc212lab05;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Brandon
 */
public class Main {

   
    public static void main(String[] args) throws Exception {
        
        String line;
        int lineNum = 0;
        
        File input = new File("myfile.txt");
        Scanner sc = new Scanner(input);
        
        while(sc.hasNextLine() == true)
        {
            lineNum++;
            line = sc.nextLine();
            System.out.println(lineNum + " : " + line.toUpperCase());
        }
        System.out.println("End of file reached");
    }
    
}
